document.addEventListener('DOMContentLoaded', function() {
  // Mobile Navigation
  const menuIcon = document.getElementById('menu-icon');
  const menuClose = document.getElementById('menu-close');
  const navMenu = document.getElementById('mobileMenu');
  
  if (menuIcon) {
    menuIcon.addEventListener('click', () => {
      navMenu.classList.add('active');
    });
  }
  
  if (menuClose) {
    menuClose.addEventListener('click', () => {
      navMenu.classList.remove('active');
    });
  }
  
  // Close menu when clicking on links
  document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
      navMenu.classList.remove('active');
    });
  });
  
  // Header scroll effect
  window.addEventListener('scroll', () => {
    const header = document.querySelector('header');
    if (header) {
      if (window.scrollY > 50) {
        header.style.backgroundColor = 'rgba(255, 255, 255, 0.98)';
        header.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
      } else {
        header.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
        header.style.boxShadow = 'none';
      }
    }
  });
  
  // Initialize animations
  const animateOnScroll = () => {
    const elements = document.querySelectorAll('.feature-card, .course-card, .testimonial-card');
    
    elements.forEach(element => {
      const elementPosition = element.getBoundingClientRect().top;
      const screenPosition = window.innerHeight / 1.3;
      
      if (elementPosition < screenPosition) {
        element.style.opacity = '1';
        element.style.transform = 'translateY(0)';
      }
    });
  };
  
  // Set initial state for animation
  document.querySelectorAll('.feature-card, .course-card, .testimonial-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  });
  
  // Trigger animations on load and scroll
  window.addEventListener('scroll', animateOnScroll);
  animateOnScroll(); // Initial check
});